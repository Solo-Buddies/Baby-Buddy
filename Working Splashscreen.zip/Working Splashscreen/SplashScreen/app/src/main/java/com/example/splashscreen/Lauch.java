package com.example.splashscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;


import static com.example.splashscreen.MainActivity.TIME_OUT;

public class Lauch extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lauch);


    }

    public void intent1(View view) {
        setContentView(R.layout.activity_lauch_contacts);

    }

    public void intent2(View view) {
        setContentView(R.layout.activity_lauch_log);

    }

}
