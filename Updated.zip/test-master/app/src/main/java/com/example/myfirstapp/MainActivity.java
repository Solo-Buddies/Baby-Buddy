package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.nsd.NsdManager;
import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity {
    public static int TIME_OUT = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this,Lauch.class); //For navigating to main menu page
                startActivity(intent);
                finish();

            }
        },TIME_OUT);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent1 = new Intent(MainActivity.this,Registration.class); //For navigating to registration page
                startActivity(intent1);
                finish();

            }
        },TIME_OUT);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent2 = new Intent(MainActivity.this,Contacts.class); //For navigating to the contacts page
                startActivity(intent2);
                finish();

            }
        },TIME_OUT);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent3 = new Intent(MainActivity.this,Log.class); //For navigating to the check-in log page
                startActivity(intent3);
                finish();

            }
        },TIME_OUT);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent4 = new Intent(MainActivity.this,Forgotuserpw.class); //For navigating to the credential retrieval page
                startActivity(intent4);
                finish();

            }
        },TIME_OUT);

        Button backButton = findViewById(R.id.Backbutton);
        final Context context = this;
        backButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intentback = new Intent(context, Lauch.class); //Back button on pages navigates to main menu page
                    startActivity(intentback);
            }
        });

    }
}
