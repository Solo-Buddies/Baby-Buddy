package com.example.addemergency;

public class Contact {
    String contactId;
    String contactName;
    String contactRelation;

    public Contact(){

    }

    public Contact(String contactId, String contactName, String contactRelation) {
        this.contactId = contactId;
        this.contactName = contactName;
        this.contactRelation = contactRelation;
    }

    public String getContactId() {
        return contactId;
    }

    public String getContactName() {
        return contactName;
    }

    public String getContactRelation() {
        return contactRelation;
    }
}
