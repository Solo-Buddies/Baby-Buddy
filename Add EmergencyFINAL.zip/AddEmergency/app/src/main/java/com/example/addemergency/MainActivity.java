package com.example.addemergency;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
EditText editTextName;
EditText editTextNumber;
Button buttonAddContacts;
Spinner spinnerRelationship;
    ListView listViewContacts;
    List<Contact> contactList;
DatabaseReference databaseContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseContacts = FirebaseDatabase.getInstance().getReference("contacts");


        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextNumber = (EditText) findViewById(R.id.editTextNumber);
        buttonAddContacts = (Button) findViewById(R.id.buttonAddContact);
        spinnerRelationship=(Spinner) findViewById(R.id.spinnerRelationship);

        listViewContacts =(ListView) findViewById(R.id.ListViewContacts);
        contactList = new ArrayList<>();

       buttonAddContacts.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               addContact();

           }
       });


    }

    @Override
    protected void onStart(){
        super.onStart();
        databaseContacts.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot dataSnapshot) {
                contactList.clear();
                for(DataSnapshot contactSnapshot: dataSnapshot.getChildren()) {
                    Contact contact = contactSnapshot.getValue(Contact.class);
                    contactList.add(contact);
                }
                ContactList adapter = new ContactList(MainActivity.this, contactList);
                listViewContacts.setAdapter(adapter);
            }

            @Override
            public void onCancelled( DatabaseError databaseError) {

            }
        });
    }


    private void addContact(){
        String name = editTextName.getText().toString().trim();
        String relation = spinnerRelationship.getSelectedItem().toString();
        String number = editTextNumber.getText().toString().trim();

        if(!TextUtils.isEmpty(name)){

           String id = databaseContacts.push().getKey();
           Contact contact = new Contact(id, name, relation, number);
           databaseContacts.child(id).setValue(contact);

           Toast.makeText(this, "Contact added", Toast.LENGTH_LONG).show();

        }else{
            Toast.makeText(this, "You should enter a contact", Toast.LENGTH_LONG).show();
        }
    }
}
