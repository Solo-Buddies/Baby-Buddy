package com.example.addemergency;

public class Contact {
    String contactId;
    String contactName;
    String contactRelation;
    String contactNumber;

    public Contact() {

    }

    public Contact(String contactId, String contactName, String contactRelation, String contactNumber) {
        this.contactId = contactId;
        this.contactName = contactName;
        this.contactRelation = contactRelation;
        this.contactNumber = contactNumber;
    }

    public String getContactId() {
        return contactId;
    }

    public String getContactName() {
        return contactName;
    }

    public String getContactRelation() {
        return contactRelation;
    }

    public String getContactNumber() {
        return contactNumber;
    }
}