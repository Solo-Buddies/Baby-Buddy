package com.example.addemergency;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ContactList extends ArrayAdapter<Contact> {
    private Activity context;
    private List<Contact> contactList;
    public ContactList(Activity context, List<Contact> contactList) {
        super(context, R.layout.list_layout, contactList);
        this.context = context;
        this.contactList = contactList;


    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list_layout, null, true );
        TextView textViewName= (TextView) listViewItem.findViewById(R.id.textViewName);
        TextView textViewRelation= (TextView) listViewItem.findViewById(R.id.textViewRelation);
        TextView textViewNumber = (TextView) listViewItem.findViewById(R.id.textViewNumber);
        Contact contact = contactList.get(position);
        textViewName.setText(contact.getContactName());
        textViewRelation.setText(contact.getContactRelation());
        textViewNumber.setText(contact.getContactNumber());



        return listViewItem;
    }
}
