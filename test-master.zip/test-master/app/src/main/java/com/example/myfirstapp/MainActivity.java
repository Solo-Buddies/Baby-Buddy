package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {
    public static int TIME_OUT = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this,Lauch.class);
                startActivity(intent);
                finish();

            }
        },TIME_OUT);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent2 = new Intent(MainActivity.this,Contacts.class);
                startActivity(intent2);
                finish();

            }
        },TIME_OUT);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent3 = new Intent(MainActivity.this,Log.class);
                startActivity(intent3);
                finish();

            }
        },TIME_OUT);

        Button backButton = findViewById(R.id.Backbutton);
        backButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Lauch.class));
            }
        }
    }
}
